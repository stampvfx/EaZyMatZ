bl_info = {
    "name" : "EaZyMatZ",
    "author" : "Youssef Hossam",
    "description" : "",
    "blender" : (2, 90, 1),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "You Are on a beta version currently",
    "category" : "Shading"
}

import bpy

class MainPanel(bpy.types.Panel):
    bl_label = "Basic Materials"
    bl_idname = "MainPanel_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "EaZyMatZ"

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator('shader.wood_operator', text="Wood")
        row = layout.row()
        row.operator('shader.ocean_operator', text="Ocean")
        row = layout.row()
        row.operator('shader.car_operator', text="CarPaint")
        row.operator('shader.asphalt1_operator', text="Asphalt First")
        
        

     
        
        

#WoodShaderOperator
class MATZOTWOOD(bpy.types.Operator):
    bl_label = "Assign Wood Material"
    bl_idname = 'shader.wood_operator'
    def execute(self, context):
        #CreateWoodShader
        material_wood = bpy.data.materials.new(name = "Wood")
        material_wood.use_nodes = True

        material_output = material_wood.node_tree.nodes.get('Material Output')
        
        
        #princibledbsdf
        BSDF = material_wood.node_tree.nodes.get('Principled BSDF')

        #definelocation
        material_output.location = (2.3,0)

        #ColorRampNode
        colorramp_node = material_wood.node_tree.nodes.new('ShaderNodeValToRGB')


        #definelocaton
        colorramp_node.location = (200, 6)
       
        colorramp_node.color_ramp.elements[0].color = (0.141263, 0.0865005, 0.0395462, 1)
        colorramp_node.color_ramp.elements[1].color = (0.274677, 0.171441, 0.0722719, 1)


        #NoiseTexNode
        noisetex_node = material_wood.node_tree.nodes.new('ShaderNodeTexNoise')

        #definelocation
        noisetex_node.location = (-200, 6)
        
        noisetex_node.inputs[4].default_value = 0.766667

        #definesettings

        noisetex_node.inputs[2].default_value = 1
        noisetex_node.inputs[3].default_value = 16
        noisetex_node.inputs[5].default_value = 1



        #MappingNode
        mapping_node = material_wood.node_tree.nodes.new('ShaderNodeMapping')

        #definelocation
        mapping_node.location = (-20, 8)

        #definesettings
        mapping_node.inputs[3].default_value[1] = 6.45

        #TexCoord
        texcoord_node = material_wood.node_tree.nodes.new('ShaderNodeTexCoord')

        #definelocation
        texcoord_node.location = (45, 5)
        
        
        #Bump
        bump_node = material_wood.node_tree.nodes.new('ShaderNodeBump')

        #definelocation
        bump_node.location = (90, 12)



        material_wood.node_tree.links.new(noisetex_node.outputs[0], colorramp_node.inputs[0])
        material_wood.node_tree.links.new(noisetex_node.outputs[1], bump_node.inputs[2])
        material_wood.node_tree.links.new(mapping_node.outputs[0], noisetex_node.inputs[0])
        material_wood.node_tree.links.new(texcoord_node.outputs[3], mapping_node.inputs[0])
        material_wood.node_tree.links.new(bump_node.outputs[0], BSDF.inputs[19])
        material_wood.node_tree.links.new(colorramp_node.outputs[0], BSDF.inputs[0])
        



        bpy.context.object.active_material = material_wood
        
        
        
        return {'FINISHED'}

        
        
        
        
        
#OceanShaderOperator
class MATZOTOCEAN(bpy.types.Operator):
    bl_label = "Assign Wood Material"
    bl_idname = 'shader.ocean_operator'
    def execute(self, context):
        #CreateOceanShader
        material_ocean = bpy.data.materials.new(name = "Ocean")
        material_ocean.use_nodes = True

        material_output = material_ocean.node_tree.nodes.get('Material Output')
        
        
        #princibledbsdf
        BSDF = material_ocean.node_tree.nodes.get('Principled BSDF')

        #definelocation
        material_output.location = (2.3,0)
        BSDF.location = (200,-90)
        
        
        
        BSDF.inputs[0].default_value = (0, 0.078871, 1, 1)
        BSDF.inputs[15].default_value = 1
        bpy.context.object.active_material = material_ocean
        
        return {'FINISHED'}
    
    
    
    
    
    
    
    
    
    #CarShaderOperator
class MATZOTCAR(bpy.types.Operator):
    bl_label = "Assign Wood Material"
    bl_idname = 'shader.car_operator'
    def execute(self, context):
        #CreateOceanShader
        material_car = bpy.data.materials.new(name = "CarMat")
        material_car.use_nodes = True

        material_output = material_car.node_tree.nodes.get('Material Output')
        
        
        #princibledbsdf
        BSDF = material_car.node_tree.nodes.get('Principled BSDF')

        #definelocation
        material_output.location = (2.3,0)
        BSDF.location = (200,-90)
        
        
        
        #colorrampnode
        
        colorrampcar_node = material_car.node_tree.nodes.new('ShaderNodeValToRGB')
        colorrampcar_node.color_ramp.elements[0].color = (1, 0.312009, 0.0291604, 1)
        colorrampcar_node.color_ramp.elements[1].color = (1, 0.117874, 0, 1)
        
        #layerweightnode 
        layerweightcar_node = material_car.node_tree.nodes.new('ShaderNodeLayerWeight')
        
        
        
        #lets link our nodes now :)
        
        material_car.node_tree.links.new(colorrampcar_node.outputs[0], BSDF.inputs[0])
        material_car.node_tree.links.new(layerweightcar_node.outputs[1], colorrampcar_node.inputs[0])
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        bpy.context.object.active_material = material_car
        
        return {'FINISHED'}
    
    
    
    
    
    
    
    
    
     
    #Asphalt1ShaderOperator
class MATZOTASPHALT1(bpy.types.Operator):
    bl_label = "Assign Wood Material"
    bl_idname = 'shader.asphalt1_operator'
    def execute(self, context):
        #CreateAsphalt1Shader
        material_asphalt1 = bpy.data.materials.new(name = "Asphalt1Mat")
        material_asphalt1.use_nodes = True
        
        
        
        #materialoutput
        material_output = material_asphalt1.node_tree.nodes.get('Material Output')
        
        
        #princibledbsdf
        BSDF = material_asphalt1.node_tree.nodes.get('Principled BSDF')

        #definelocation
        material_output.location = (2.3,0)
        BSDF.location = (200,-90)
        
        
        #this is for the mixrgb input
        noiseasphalt1_node= material_asphalt1.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseasphalt1_node.inputs[2].default_value = 10
        noiseasphalt1_node.inputs[3].default_value = 16
        
        
        
        #this is the only uvmapnode in this mat :)
        uvmapasphalt1_node = material_asphalt1.node_tree.nodes.new('ShaderNodeUVMap')
        
        
        #this mix is for nosietex1 and uv map
        mixrgbasphalt1_node = material_asphalt1.node_tree.nodes.new('ShaderNodeMixRGB')
        mixrgbasphalt1_node.inputs[0].default_value = 0.05
        
        
        
        #this is the second noise texture, which is for mixrgb1 output
        noiseasphalt2_node = material_asphalt1.node_tree.nodes.new('ShaderNodeTexNoise')
        noiseasphalt2_node.inputs[2].default_value = 50
        noiseasphalt2_node.inputs[3].default_value = 16
        
        
        
        #this is our first colorramp, which for noisetex2 output and mixrgb2 input we use this to make it black and white :)
        colorasphalt1_node = material_asphalt1.node_tree.nodes.new('ShaderNodeValToRGB')
        
        
        #this mix is our second one and which we will use to inout colorramp1 and output colorramp 2
        mixrgbasphalt2_node = material_asphalt1.node_tree.nodes.new('ShaderNodeMixRGB')
        
    
        
        
        
        #this the secone color ramp we will use this to input mixrgb2 and output colorramp3 ;)
        colorasphalt2_node = material_asphalt1.node_tree.nodes.new('ShaderNodeValToRGB')
        colorasphalt2_node.color_ramp.elements[0].position = 0.204545
        colorasphalt2_node.color_ramp.elements[1].position = 0.327273
        
        
        
        #this is the 3rd color ramp node which we will use to apply our colours
        colorasphalt3_node = material_asphalt1.node_tree.nodes.new('ShaderNodeValToRGB')
        colorasphalt3_node.color_ramp.elements[0].position = 0.15
        colorasphalt3_node.color_ramp.elements[0].position = 0.809091
        
        colorasphalt3_node.color_ramp.elements[0].color = (0.0802198, 0.114435, 0.168269, 1)
        colorasphalt3_node.color_ramp.elements[1].color = (0.0212635, 0.0266884, 0.0560386, 1)
       
    
        #this is our first and only voronoi texture in the whole mat :)s
        texvornasphalt1_node = material_asphalt1.node_tree.nodes.new('ShaderNodeTexVoronoi')
        
        
        texvornasphalt1_node.feature = 'DISTANCE_TO_EDGE'
        texvornasphalt1_node.inputs[2].default_value = 50
        
        
        
        #this is the fourth colorramp in our scene and the is the last one in our mat ;)
        colorasphalt4_node = material_asphalt1.node_tree.nodes.new('ShaderNodeValToRGB')
     
     
     
     
        #now let's create the only bump node in out material :)
        bumpasphalt1_node = material_asphalt1.node_tree.nodes.new('ShaderNodeBump')
        
        
        
        
        
        
        
        
        
        
        #now lets link our nodes
        
        
        link = material_asphalt1.node_tree.links.new
        
        link(noiseasphalt1_node.outputs[1], mixrgbasphalt1_node.inputs[2])
        link(uvmapasphalt1_node.outputs[0], mixrgbasphalt1_node.inputs[1])
        link(mixrgbasphalt1_node.outputs[0], noiseasphalt2_node.inputs[1])
        link(noiseasphalt2_node.outputs[1], colorasphalt1_node.inputs[0])
        link(colorasphalt1_node.outputs[0], mixrgbasphalt2_node.inputs[1])
        link(mixrgbasphalt2_node.outputs[0], colorasphalt2_node.inputs[0])
        link(colorasphalt2_node.outputs[0], colorasphalt3_node.inputs[0])
        link(colorasphalt3_node.outputs[0], BSDF.inputs[0])
        link(texvornasphalt1_node.outputs[0], mixrgbasphalt2_node.inputs[2])
        link(mixrgbasphalt2_node.outputs[0], colorasphalt4_node.inputs[0])
        link(colorasphalt4_node.outputs[0], bumpasphalt1_node.inputs[2])
        link(bumpasphalt1_node.outputs[0], BSDF.inputs[19])
             
        
        
        
     
        

        
      
       
        
     
        
        
        
        
        
      
   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        bpy.context.object.active_material = material_asphalt1
        
        return {'FINISHED'}
        




        














        







    


def register():
    bpy.utils.register_class(MainPanel)
    bpy.utils.register_class(MATZOTWOOD)
    bpy.utils.register_class(MATZOTOCEAN)
    bpy.utils.register_class(MATZOTCAR)
    bpy.utils.register_class(MATZOTASPHALT1)
    


def unregister():
    bpy.utils.unregister_class(MainPanel)
    bpy.utils.unregister_class(MATZOTWOOD)
    bpy.utils.unregister_class(MATZOTOCEAN)
    bpy.utils.unregister_class(MATZOTCAR)
    bpy.utils.unregister_class(MATZOTASPHALT1)
    


if __name__ == "__main__":
    register()

